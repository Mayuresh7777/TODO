package com.cg.employee.rest;

import java.util.NoSuchElementException;
import java.util.stream.StreamSupport;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.cg.employee.entity.Employee;
import com.cg.employee.service.IEmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	private IEmployeeService service;

	// consumes json object
	@PostMapping(path = "/createemployee", consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> addEmployee(@RequestBody(required = false) Employee emp) {
		if (emp != null) {
			// if employee object is not null then perform below operations
			service.saveEmployee(emp);
			return new ResponseEntity<String>("Employee added Successfully", HttpStatus.OK);
		} else
			return new ResponseEntity<String>("Blank Employee can not be added", HttpStatus.BAD_REQUEST);
		// if emp object is null then exception will be thrown
	}

	@GetMapping(name = "/getbyid", produces = "application/json")
	public ResponseEntity<?> getEmployee(@RequestParam("empid") int id) {
		// if id exist in dataBase then employee object will be return
		// else exception will be thrown
		try {
			Employee emp = service.getById(id);
			return new ResponseEntity<Employee>(emp, HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
		}

	}

	@GetMapping(path = "/employees", produces = "application/json")
	public ResponseEntity<?> getAllEmployees() {
		// getting all the employees from the database
		Iterable<Employee> employees = service.findAll();
		// take a count of all the employess
		long count = StreamSupport.stream(employees.spliterator(), false).count();
		// if count is zero means there are no employees in database
		// hence exception will be thrown at that time
		if (count != 0)
			return new ResponseEntity<Iterable<Employee>>(employees, HttpStatus.OK);
		else
			return new ResponseEntity<String>("No Employee Found to show", HttpStatus.BAD_REQUEST);
	}

	// consumes json object
	@PutMapping(path = "/updateemployee", consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> updateEmployee(@RequestBody(required = false) Employee emp) {
		if (emp != null) {
			// if employee object is not null then perform below operations
			service.saveEmployee(emp);
			return new ResponseEntity<String>("Employee updated Successfully", HttpStatus.OK);
		} else
			return new ResponseEntity<String>("Blank Employee can not be update", HttpStatus.BAD_REQUEST);
		// if emp object is null then exception will be thrown
	}

	@DeleteMapping(name = "/deleteemployee", produces = "application/json")
	public ResponseEntity<String> deleteEmployee(@RequestParam("empid") int id) {
		// if id exist in dataBase then employee object will be delete
		// else exception will be thrown
		try {
			service.deleteEmployee(id);
			return new ResponseEntity<String>("Employee sucessfully deleted", HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping(path = "/employees/{deptName}", produces = "application/json")
	public ResponseEntity<?> getEmployeesBydept(@PathVariable String deptName) {
		// getting all the employees from the database filter by deptName
		Iterable<Employee> employees = service.findAllByDept(deptName);
		// take a count of all the employess
		long count = StreamSupport.stream(employees.spliterator(), false).count();
		// if count is zero means there are no employees in database
		// hence exception will be thrown at that time
		if (count != 0)
			return new ResponseEntity<Iterable<Employee>>(employees, HttpStatus.OK);
		else
			return new ResponseEntity<String>("No Employee Found to show", HttpStatus.BAD_REQUEST);
	}
}
