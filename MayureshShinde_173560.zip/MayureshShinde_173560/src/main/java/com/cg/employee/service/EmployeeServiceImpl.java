package com.cg.employee.service;

import java.util.NoSuchElementException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cg.employee.dao.EmployeeDao;
import com.cg.employee.entity.Employee;

//Indicates that an annotated class is a "Service"
@Service
// At the class level, this annotation applies as a default to all methods of
// the declaring class and its subclasses.
@Transactional
public class EmployeeServiceImpl implements IEmployeeService {

	@Autowired
	private EmployeeDao dao;

	@Override
	public void saveEmployee(Employee emp) {
		// Saving employee to the database
		dao.save(emp);
	}

	@Override
	public Employee getById(int id) throws NoSuchElementException {
		try {
			// Return employee if exitst in database
			return dao.findById(id).get();
		} catch (NoSuchElementException e) {
			// if record does not exist in database then exception will be thrown
			throw new NoSuchElementException("Employee Record not found for id = " + id);
		}
	}

	@Override
	public void deleteEmployee(int id) throws NoSuchElementException {
		try {
			// if record found in database then employee will be deleted
			dao.delete(dao.findById(id).get());
		} catch (NoSuchElementException e) {
			// if record does not exist in database then exception will be thrown
			throw new NoSuchElementException("Employee Record not found for id = " + id);
		}
	}

	@Override
	public Iterable<Employee> findAll() {
		// return all employees from database
		return dao.findAll();
	}

	@Override
	public Iterable<Employee> findAllByDept(String deptName) {
		// return all employees from database where deptName will match
		return dao.findAllByDeptName(deptName);
	}

}
