package com.cg.employee.dao;

import org.springframework.data.repository.CrudRepository;

import com.cg.employee.entity.Employee;

public interface EmployeeDao extends CrudRepository<Employee, Integer> {

	// Method to find all employees from specific department
	Iterable<Employee> findAllByDeptName(String deptName);
}
