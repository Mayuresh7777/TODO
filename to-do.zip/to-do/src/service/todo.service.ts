import { TodosModel } from './../app/models/Todos';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class TodoService {
  todos: TodosModel[];
  todoForEdit: TodosModel;
  findTodo: TodosModel;
  constructor(private routes: Router) {
    this.todos = []
  }
  getTodos() {
    return this.todos;
  }
  //go to create pagfe for add task
  addTask() {
    this.routes.navigate(['/create']);
  }
  back() {
    this.routes.navigate(['/todo']);
  }
  //push todos details in array
  enterTask(act: TodosModel) {
    this.todos.push(act);
    this.routes.navigate(['/todo']);
  }
  //delete  todo
  delete(index: number) {
    this.todos.splice(index, 1);
  }
  edit(name: string) {
    this.todoForEdit = this.todos.find(x => x.name == name);
    this.routes.navigate(['/edit']);
  }
  getToDOForEdit() {
    return this.todoForEdit;
  }
  saveEdits(edit: TodosModel) {
    this.findTodo = this.todos.find(x => x.name == edit.name);
    this.findTodo.name=edit.name;
    this.findTodo.status=edit.status;
    this.routes.navigate(['/todo']);
  }
}
