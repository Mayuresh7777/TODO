import { TodosModel } from './../models/Todos';
import { TodoService } from 'src/service/todo.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
editTodo: TodosModel;
  constructor(private service: TodoService) { 
    this.editTodo=new TodosModel();
  }

  ngOnInit() {
    this.editTodo=this.service.getToDOForEdit();
  }

  back() {
    this.service.back();
  }
  saveEdits(){
    this.service.saveEdits(this.editTodo);
  }
}
