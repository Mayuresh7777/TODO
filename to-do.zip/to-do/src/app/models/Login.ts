export class LoginModel{
    private _email:string;
    private _password:string;

    constructor(){
        this._email="admin@gmail.com";
        this._password="123456";
    }
    // getters setters
    get email(){
        return this._email;
    }
    set email(lEmail:string){
        this._email=lEmail;
    }
    get password(){
        return this._password; 
    }
    set password(pass :string){
        this._password=pass;
    }
}