import { LoginModel } from './../models/Login';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  login: LoginModel;
  getLogin: LoginModel;
  valid: boolean;
  checkEmailSize: boolean;
  checkPassSize: boolean;
  constructor(private routes: Router) {
    this.login = new LoginModel();
    this.getLogin = new LoginModel();
    this.getLogin.password = "";
    this.getLogin.email = "";
  }

  ngOnInit() {
  }
  // to clear the fields
  cancel() {
    this.getLogin = new LoginModel();
    this.getLogin.password = "";
    this.getLogin.email = "";
  }
  // to go back home page
  home() {
    this.routes.navigate(['/home']);
  }
  // checks login details
  checkLogin() {
    if (this.getLogin.email == "") {
      this.checkEmailSize = true;
    }
    if (this.getLogin.password == "") {
      this.checkPassSize = true;
    }
    if (this.getLogin.email == this.login.email && this.getLogin.password == this.login.password) {
      this.valid = false;
      this.checkEmailSize = false;
      this.checkPassSize = false;
      this.routes.navigate(['/todo']);
    }
    else this.valid = true;
  }
}
